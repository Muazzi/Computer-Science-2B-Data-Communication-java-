package za.ac.uj.acsse.csc2b.pta.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * @author STUDENT_NUMBER here
 */
public class POSTITClient
{ 
	private  Socket  socket ; 
	private  PrintWriter  txout ; 
	private  BufferedReader in ; 
	private  OutputStream  os ; 
	private  InputStream  input;
	
	public POSTITClient()
	{
		// Create socket   
		try {
			socket= new  Socket ("localhost",2015);
		   os  = socket.getOutputStream(); 
		   txout = new PrintWriter(os); 
		   input=socket.getInputStream();
		   in = new  BufferedReader(new InputStreamReader(input));
		   
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		// Bind streams
	}

	public void sendMessage(String message)
	{
		// Send text message
		txout.println(message);
		txout.flush();
	}

	public String getResponse()
	{
		// Get text response
		String res = null;
		try {
			res = in.readLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return  res;
	}   
	
	public PrintWriter  getTxtout()
	{
		 return  txout; 
	}
	
	public  OutputStream getOS()
	{
		return  os;
	}

	public InputStream getInput() {
		return input;
	}

	public void setInput(InputStream input) {
		this.input = input;
	}
}
