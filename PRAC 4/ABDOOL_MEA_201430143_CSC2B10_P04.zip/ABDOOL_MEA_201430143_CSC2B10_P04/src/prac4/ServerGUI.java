package prac4;

import java.awt.BorderLayout;

import javax.swing.JPanel;
import javax.swing.JTextArea;

public class ServerGUI extends javax.swing.JFrame {
private   JTextArea area =new JTextArea(); 
public JTextArea getArea() {
	return area;
}

public void setArea(JTextArea area) {
	this.area = area;
}

private JPanel panel; 

ServerGUI()
{   
	area.setEditable(false);
	this.setSize(400, 400);
	this.setLayout(new BorderLayout());
	panel = new  JPanel(); 
	panel.setLayout(new BorderLayout());
	panel.add(area,BorderLayout.CENTER);
	add(panel,BorderLayout.CENTER); 
	setVisible(true);
	
}
}
