import Gui.ApplicationFrame;
/**
 * 
 * @author Muaz
 * This will  create gui  in  the form  of the client 
 */ 
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    ApplicationFrame  game = new  ApplicationFrame(500,600);//  setting the  size  of the canvas
    
   
	}

}
