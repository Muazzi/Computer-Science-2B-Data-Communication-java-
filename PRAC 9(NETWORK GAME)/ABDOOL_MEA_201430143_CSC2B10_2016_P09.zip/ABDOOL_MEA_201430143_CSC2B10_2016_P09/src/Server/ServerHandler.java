package Server;

import java.net.Socket;
import java.util.Random;

import Gui.Protocolhandler;
import Gui.player;

public class ServerHandler implements Runnable {
	private  Socket PlayerSocket,PlayerSocket2 ;  //  players  socket 
	private player Player1 , Player2,goal =null;//  these  our  objects  which  will  exist in our  world  
	
    /**
     *  
     * @param PlayerSocket this will  be  player one socket
     * @param PlayerSocket2 this will  be used for  player2  sokcet 
     */
	public ServerHandler (Socket  PlayerSocket, Socket PlayerSocket2 )
	{ 

		this.PlayerSocket=  PlayerSocket; 
		this.PlayerSocket2=  PlayerSocket2;
		
	} 
	@Override
	public void run() {
		// TODO Auto-generated method stub
		Player1 = new player(0,0,PlayerSocket); //  we  creating  player  one  on top  of and placing at the top 
		Player2 =new player(9,9 ,PlayerSocket2 );//  we  creating  player  two  at the other end    
		int r =RandomNumber(0,9);//  we  getting  a random  row number 
		int c =RandomNumber(0,9);// random column  for  the goal
		
		goal = new player(r,c,null);// was lazy  just made  my goal  same as player  it will  be randomized each  time 
		
		Protocolhandler first = new Protocolhandler(Player1,Player2,goal); //protocol handler to  send messages from player to player
		Protocolhandler second = new Protocolhandler(Player2,Player1,goal); // protocol handler to send messages to one another  from player to player and to follow the similar  protocol 
		Thread one,two; 
		one = new Thread(first);
		two = new Thread(second); 
		one.start();//start  each one  
		two.start();//start each one 
		
		
		
			
		}
	
 private int RandomNumber(int min ,  int max)
 {
	
	 Random rand = new Random();
	 long range= (long)max-(long)min +1; 
	 long fraction = (long)(range*rand.nextDouble());
	 int randomnum=(int)(fraction+min);
	 return  randomnum;
 }
}
