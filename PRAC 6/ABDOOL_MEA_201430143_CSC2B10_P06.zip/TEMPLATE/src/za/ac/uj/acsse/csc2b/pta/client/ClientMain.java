
package za.ac.uj.acsse.csc2b.pta.client;

import javax.swing.JFrame;

/**
 * @author STUDENT_NUMBER here
 */
public class ClientMain
{

	public static void main(String[] args)
	{
		POSTITClientFrame clientFrame= new POSTITClientFrame() ;
		clientFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		clientFrame.setLocationRelativeTo(null);
		clientFrame.setVisible(true);
	}
}
