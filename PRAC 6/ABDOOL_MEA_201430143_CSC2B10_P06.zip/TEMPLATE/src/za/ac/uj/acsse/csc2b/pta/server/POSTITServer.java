package za.ac.uj.acsse.csc2b.pta.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * @author STUDENT_NUMBER here
 */
public class POSTITServer
{   
	private  ServerSocket serversock;
	public POSTITServer(int port)
	{
		//	Create server socket
		try {
			serversock =new ServerSocket (port);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * 
	 */
	public void start()
	{
		//	Accept clients
		//	Handle multiple clients
		boolean handel = true; 
		while (handel)
		{
			try {
				Socket client  =  serversock.accept() ;
				
				POSTITHandler handler = new POSTITHandler(client);
				Thread t = new Thread(handler); 
				t.start();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			
			
		}
		
		
	}

}
