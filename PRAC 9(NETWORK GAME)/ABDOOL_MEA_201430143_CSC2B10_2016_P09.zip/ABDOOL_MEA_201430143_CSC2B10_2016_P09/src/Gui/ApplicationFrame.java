package Gui;

import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.StringTokenizer;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

public class ApplicationFrame extends Canvas {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private  GamePanel  gpanel =  new  GamePanel(this); // gamepanel  containg the world itself
	private Socket PlayerSocket=null;//  playersocket 
	private  PrintWriter txtout; 
	private InputStream  input; 
	private  OutputStream  output;
	private BufferedReader reader;
	private  int width;
	private int  height;
	/**
	 * 
	 * @param width the width of the canvas
	 * @param height the height of the canvas 
	 */
	 public ApplicationFrame( int  width , int  height)
	 {  
		 this.width=width; 
		 this.height=height;
		 setupFrame();
		 
		 
		
	 }
	 /**
	  * will  setup the frame  and perform  all  game logic 
	  */
	private void setupFrame() {
		// TODO Auto-generated method stub
		 gpanel.setVisible(true);//setting up our panel to  show
		 gpanel.setFocusable(true);// giving it focus
		JFrame  GameFrame  =  new  JFrame();// we have a gameframe
		 JMenuBar menubar = new JMenuBar() ; //  have a menubar
		   JMenu   start = new JMenu("Newgame "); // will apear on the frame as we start 
		   JMenu   rules = new JMenu("Rules "); 
		   JMenuItem   connectitem = new JMenuItem("Create a  game session"); 
		   JMenuItem   gamerules= new JMenuItem("GameRules");
		   rules.add(gamerules);
		   start.add(connectitem);
		   menubar.add(rules);
		   menubar.add(start);
		   GameFrame.setTitle("HARAMBE AND MONKEYS GO  BANANAS");
		 //  menubar.setVisible(true);
		   GameFrame.add(menubar, BorderLayout.NORTH);// aligning the menubar to the top of the frame
			connectitem.addActionListener(new  ActionListener()// USER CLICKS  EVENT WILL OCCUR
					
					{

						@Override
						public void actionPerformed(ActionEvent arg0) {
							// TODO Auto-generated method stub
							
							
							
								try { 
									
									 PlayerSocket = new  Socket ("localhost", 3333);// we create a socket when  we start  a game session 
									  SetupStreams(PlayerSocket);// setting up the streams for the playersokcet 
									  
									  
									 
								      new Thread()
								     { ///  the game is gonna be updated as each players send commands  so we using athread
								    	    public void run() {
								    	    	while(true)
								    	    	{
								    	        String message= readresponse();//  we get the response from the server
								    	        StringTokenizer protocol = new StringTokenizer(message," "); //match our protocl
								    	       String cmd= protocol.nextToken();//  we skkiping one  token 
								    	       switch(cmd)
								    	       {
								    	       case"BANANA": 
								    	    	  if(gpanel.getGoal()!=null)
								    	    	  {
								    	    		 gpanel.getWorld()[gpanel.getGoal().getRow()][gpanel.getGoal().getCol()].setIcon(gpanel.getBlank()); // seting upp our  bananas 
								    	    	  }
								    	    	  else
								    	    	  {
								    	    		  gpanel.setGoal(new player(4,4,null));
								    	    	  }
								    	    	  
								    	    	  gpanel.getGoal().setRow(Integer.parseInt(protocol.nextToken()));//  we sending the goalrow  eachtime we connect to  server this sets it in the world
								    	    	  gpanel.getGoal().setCol(Integer.parseInt(protocol.nextToken()));//  we sending the goalcol  eachtime we connect to  server this sets it in the world
								    	    		 gpanel.getWorld()[gpanel.getGoal().getRow()][gpanel.getGoal().getCol()].setIcon(gpanel.getBanana());
								    	    		 break; 
								    	       case "MONKEY":
								    	    	   
								    	    	   if(gpanel.getP()!=null)
									    	    	  {
									    	    		 gpanel.getWorld()[gpanel.getP().getRow()][gpanel.getP().getCol()].setIcon(gpanel.getBlank());//seting our monkey player 1 in the world 
									    	    	  }
									    	    	  else
									    	    	  {
									    	    		  gpanel.setP(new player(0,0,null));
									    	    	  }
									    	    	  
									    	    	  gpanel.getP().setRow(Integer.parseInt(protocol.nextToken()));//setting the row  of player 1
									    	    	  gpanel.getP().setCol(Integer.parseInt(protocol.nextToken()));//setting the col  of player 1
									    	    		 gpanel.getWorld()[gpanel.getP().getRow()][gpanel.getP().getCol()].setIcon(gpanel.getPlayer1());//  giving it an icon
									    	    		 break; 
									    	    		 
 case "BABOON":

								    	    	   if(gpanel.getP2()!=null)
									    	    	  {
									    	    		 gpanel.getWorld()[gpanel.getP2().getRow()][gpanel.getP2().getCol()].setIcon(gpanel.getBlank()); // we  setting the baboon  icon 
									    	    	  }
									    	    	  else
									    	    	  {
									    	    		  gpanel.setP2(new player(0,0,null));
									    	    	  }
									    	    	  
									    	    	  gpanel.getP2().setRow(Integer.parseInt(protocol.nextToken()));// using row from server
									    	    	  gpanel.getP2().setCol(Integer.parseInt(protocol.nextToken()));//using col from  server
									    	    		 gpanel.getWorld()[gpanel.getP2().getRow()][gpanel.getP2().getCol()].setIcon(gpanel.getPlayer2());//  displaying baboon icon  after setting it up in the world
									    	    		 break; 
								    	    	   
 case"WIN":
	
	 JOptionPane.showMessageDialog(gpanel, "Well  done you Have won the Game");
	 GameFrame.setVisible(false);
	 GameFrame.dispose();
	 
	 break;
 case"LOSE":
	 JOptionPane.showMessageDialog(gpanel, "You lose");
	 GameFrame.setVisible(false);
	 GameFrame.dispose();
	 
 break;

								    	    		  
								    	    	   

								    	    		  
								    	       }
								    	        
								    	        
								    	    }}
								    	}.start();
								    		 
								    		
				
									 
								
									
									 
									 
									
								} catch (UnknownHostException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								} 
									
							
					
						}
							}
						
					);
			  
			GameFrame.add(menubar, BorderLayout.NORTH);
			gamerules.addActionListener(new  ActionListener()
					
					{

						@Override
						public void actionPerformed(ActionEvent arg0) {
							// TODO Auto-generated method stub
							JOptionPane.showMessageDialog(null, "WELCOME TO  HARAMBE AND  MONKEYS GO  BANANAS :  "+"Play  on  a network and  collect the banana  its  a naughty banana "
									+ "score  one point  on  touching the  banana the player  who  gets  3 points wins "+"controls"+
									"w: Move up "+" s : Move down"+"a:Move left"+"d: Move right"+"*********************"+"if  movement does not work first click  tab as with all games a bug  is  a feature -_-"
							
							

									);
								
									
						}
				
					}
					);		
			
			GameFrame.setPreferredSize(new Dimension(width,height));
			GameFrame.setMaximumSize(new Dimension(width, height));
			GameFrame.setMinimumSize(new Dimension(width, height));
		    GameFrame.setResizable(false);
		   GameFrame .setVisible(true);
		   GameFrame .setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		    GameFrame.setTitle("Reach the goal");
		    GameFrame.setLocationRelativeTo(null);
		    GameFrame.add(gpanel,BorderLayout.CENTER);
		   
		
	}
	private void SetupStreams(Socket playerSocket2) {
		// TODO Auto-generated method stub  
		try {
			input = playerSocket2.getInputStream();
			output=playerSocket2.getOutputStream();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		txtout= new PrintWriter(output);
		reader= new BufferedReader(new  InputStreamReader(input));
		
		
	} 
	public void  SendToServer(String message)
	{
		txtout.println(message);
		txtout.flush();
	}  
	private  String    readresponse()
	{ 
		String  response="";
	  try {
		  response=	reader.readLine();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	  return  response; 
	}
	
	 
	 
}
