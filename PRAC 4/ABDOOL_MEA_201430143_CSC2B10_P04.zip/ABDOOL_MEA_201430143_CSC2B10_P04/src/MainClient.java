import prac4.Client;

public class MainClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Client cl = new Client("muaz","localhost",0) ;
	}

}
