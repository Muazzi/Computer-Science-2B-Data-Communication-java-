import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
/**
this class will  make run our server on port 888 
**/
public class MagicBall_Server {
 private static int PORT =8888; //portn 8888
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
      new MagicBall_Server().run_server();
	}
	public void run_server() throws IOException
	{     
		ServerSocket ser= new  ServerSocket(PORT); 	
		System.out.println("awaiting connections.......");
		
		while(true )
		{
			Socket s = ser.accept(); 
			new ServerThread(s).start();
			
		}
	}

}
