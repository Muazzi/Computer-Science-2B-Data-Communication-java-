import prac4.server;

public class servermain {
	private int port;
	private server Server;
	public servermain (int port)
	{
		this.port=port;
		Server=new server(port);
		
	}
public  static  void main(String []args)
{  

	int port=9999; 
	
	
	//port= Integer.parseInt(args[0]);
	new  servermain(port);
		
}
}
