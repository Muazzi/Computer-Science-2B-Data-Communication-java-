package data;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;


import java.util.ArrayList;

import java.util.Scanner;
import java.util.StringTokenizer;

import javax.imageio.ImageIO;





public class ServerHandler implements  Runnable   {
private  Socket sock ;
 private ArrayList<ImageServer> list = new ArrayList<ImageServer>();
private  PrintWriter txtout; 
private  BufferedReader  in ; 
private OutputStream	os;

public ServerHandler (Socket s) 
{
	setSock(s);
	try 
	{
		os=s.getOutputStream(); 
		in= new  BufferedReader(new  InputStreamReader(s.getInputStream()));
		txtout= new  PrintWriter(os);
		
	} 
	catch(IOException e)
	{
		e.printStackTrace();
	}
}

public Socket getSock() {
	return sock;
}

public void setSock(Socket sock) {
	this.sock = sock;
} 
private   ArrayList<ImageServer>   readTextfile()
{  
	 ArrayList<ImageServer> images  = new ArrayList<ImageServer>();
	ImageServer i = null;
	Scanner  txtin = null ;
	String  line  ="";
	File file = new  File ("data/server/test.txt");
	
	try
	{
	
	    txtin = new  Scanner (file);	
		
			
			 
			  System.out.println("reading file");
			while (txtin.hasNext())
			{
				line= txtin.nextLine();
				
				String [] ar = line.split(" "); 
				int id = Integer.parseInt(ar[0]) ;
				
				String name =  ar[1];
				
			    i = new ImageServer(id ,  name); 
				images.add(i);
			}  
		
		
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	finally
	{
		if(txtin!=null) txtin.close();
		
			
		
			
	}
	return  images; 
}
@Override
public void run() {
	// TODO Auto-generated method stub
	System.out.println("processing commands");
	boolean processing = true; 
	try
	{
		while(processing)
		{
			String message= in.readLine(); 
			StringTokenizer messagetokens = new StringTokenizer(message);
			String command = messagetokens.nextToken().toUpperCase();
			//sendListToClient();
			switch (command )
			{
			case "LIST":
				System.out.println("List function  upcoming ");
				
				sendListToClient();
				break; 
			case "RET": 
				BufferedImage img = null;
				System.out.println("Process ret  command");
				 String id  = messagetokens.nextToken();
				
				 int image_id =  Integer.parseInt(id);
				 String n =findimage(image_id); 
				 System.out.println(n);
				 try
				 {
					 img = ImageIO.read(new File("data/server"+n));
				 }
				 catch (IOException ex)
				 {
					 ex.printStackTrace();
				 }
				 finally
				 {
					 ImageIO.write(img, "BMP", os);
				 }
				 
				 break;
				 
			    
				
				
			
				
			}
		}
	}
	catch (IOException e)
	{
		e.printStackTrace();
	}
	
}



private String  findimage(int image_id) {
	// TODO Auto-generated method stub
	String filename = null;
	for(int i = 0; i<list.size();i++)
	{
		if(list.get(i).getId()==image_id)
		{
			filename= list.get(i).getName();
	     
		}
	} 
	   return  filename;
}

private void sendListToClient() {
	// TODO Auto-generated method stub
	 list = readTextfile(); 
	
     try {
    	 ObjectOutputStream objectOutput = new ObjectOutputStream(sock.getOutputStream());
		objectOutput.writeObject(list);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		System.out.println("did not send");
		e.printStackTrace();
	}           
	 
}
private BufferedImage readimage(String filename)
{
	BufferedImage image = null;
	try 
	{
		image= ImageIO.read(new  File(filename));
	}
	catch (IOException ex)
	{
		ex.printStackTrace();
	}
	return image;
}
}
