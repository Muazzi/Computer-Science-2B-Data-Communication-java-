package Server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;


public class MainServer {
   
	
	private static ServerSocket  serversocket =null; 
	final static int  PORT = 3333; // the port which our  clients will  send their  requeststo 

	/**
	 * Start the server  and wait on  port  and also  allow for multiple players to connect to the server  
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        try {
			serversocket = new  ServerSocket (PORT);//serversocket  running on  port  
			System.out.println("awaiting connection  on Port"+PORT);//  waiting for  the connection
			while (true )
			{ 
				
				Socket player =  serversocket.accept(); // assign player 1 sokcet
				Socket player2 =  serversocket.accept();  //  assign  player 2 socket 
				
				
				
				
					ServerHandler handler = new  ServerHandler(player,  player2);//  server  handler  will  take  player1 and  player 2 socket 
					Thread t= new Thread(handler); 
					t.start();
				
				
				
					
					
					
					
				
					
					
				
				
			}
			
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
       
        }
        

}
