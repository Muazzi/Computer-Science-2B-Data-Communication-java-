/**
 * @author Muaz Abdool
 *  201430143
 */
import java.io.IOException;
import java.net.Inet4Address;
import java.net.Socket;
import java.net.UnknownHostException;


public class Main 
{
	/**
	 * Main Function for program running
	 * @param args
	 */
	public static void main(String[] args)
	{	
		
		Socket newConnection = null;
		for(int a = 1; a <= 65535; a++)	{
		try 
		
		{
			
				
				newConnection = new Socket("127.0.0.1", a);// creating a socket object  to  the localhost
				System.out.println(" IP Address: "+Inet4Address.getLocalHost().getHostAddress()+"\r\n"+"successful connection at port "+a);
							
			
		} 
		/**
		 * Exception Handling
		 */
		catch (UnknownHostException e)
		{
			System.err.println("Failed Connection " + newConnection.getLocalPort());
		} 
		catch (IOException e)
		{
			System.err.println("Failed Connection at Port " + a);
		}
		finally
		{
			if(newConnection != null)
			{
				try
				{
					newConnection.close();
				}
				catch (IOException e) 
				{
					e.printStackTrace();
				}
			}
		}
		}
	}

	

	
		
		
	

		
}
