package za.ac.uj.acsse.csc2b.pta.server;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * @author STUDENT_NUMBER here
 */
public class POSTITHandler implements Runnable
{ 
	
	private Socket clientsocket;
	
	private  PrintWriter  txout ; 
	private  BufferedReader in ; 
	private  InputStream is;
	private  OutputStream  os ; 
	public POSTITHandler(Socket newConnectionToClient)
	{
		// Bind Streams
		clientsocket=  newConnectionToClient;
		   try {
			os  = clientsocket.getOutputStream();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
		   txout = new PrintWriter(os); 
		   try {
			   is=clientsocket.getInputStream();
			in = new  BufferedReader(new InputStreamReader(is));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void run()
	{
		//	Process commands from client 
		String command = null;
		boolean  isLoggedon=true;
		boolean control =  true ;
		while (control)
		{
		 
		try {
			command = in.readLine(); 
		  
			StringTokenizer message = new  StringTokenizer(command, " "); 
		String protocol =  message.nextToken(); 
		
		
		
		switch(protocol )
		{
		case "REG":
			String newname =  message.nextToken(); 
			String  newPassword =message.nextToken();
		boolean  isregistered= 	register(newname ,newPassword); 
			if(isregistered ==true )
			{
				sendResponse("#ok registration successfull"); 
				
			}
			else
			{
				sendResponse("&ERR the  user already exists "); 	
			}
			
			
			break; 
		case"LOGIN": 
			String  username=  message.nextToken(); 
			String  UserPassword =  message.nextToken();
			  isLoggedon =  authenticate(username,UserPassword ); 
			if (isLoggedon==true )
			{
				sendResponse("#ok Login  was successfull"); 
				isLoggedon=true;
			}
			else
			{
				sendResponse("#ERR Login  was  unsuccessfull please try and register first"); 
				isLoggedon=false;
			}
			break ; 
		case "POST":
			String  title = message.nextToken(); 
			
			String  ClientMessage =""; 
			  while(message.hasMoreTokens())
			  {
				  ClientMessage+=message.nextToken()+" ";
			  }
				
				
				
			 
				
			SaveImageAndMessage(title,ClientMessage);
			
		
			
			
			
			
			
			break ; 
		case "LOGOFF":
			if  (isLoggedon==true )
			{
				isLoggedon = false; 
				sendResponse("#ok  Logging of");
				control=false;
			} 
			else
			{
				sendResponse("#ERR Please register or  login "); 
			}
			
		  break;
			default:
				System.out.println("Wrong command");
				break; 
				
			
		}
				
			
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		 System.out.println(command);
		}
		
	}

	private void SaveImageAndMessage(String title, String clientMessage) throws IOException {
		// TODO Auto-generated method stub
		File postfile = new File("data/server",title+".txt");
		BufferedWriter filewriter = new BufferedWriter(new FileWriter(postfile, true));
		filewriter.write(clientMessage);
		filewriter.flush();
		filewriter.close();
		
		clearInput(is);
		BufferedInputStream bis = new BufferedInputStream(clientsocket.getInputStream());
		int filesize = Integer.parseInt(in.readLine());
		byte buffer[] = new byte[filesize];
		
		
		int total = 0;
		while(total < filesize)
		{
			total += bis.read(buffer, total, (filesize-total));
		}
	
		
		File postimage = new File("data/server/"+title + ".jpg");
		BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(postimage));
		bos.write(buffer);
		bos.flush();
		bos.close();
	}

	

	

	private boolean authenticate(String name, String password)
	{
		// Authenticate users from text file.
		
		boolean result  =true ; 
		Scanner txtin= null; 
		 String line = ""; 
		try 
		{
			txtin = new  Scanner(new File("data/server/users.txt")); 
			
			
			  line = txtin.nextLine();
				 System.out.println(line);
				 if (line.contains(name))
				 {
					 if(line.contains(password))
					 {
						   result=true ; 
					 }
				 }
				 else
				 {
					result = false; 
					
				 }
			 
		} 
		catch(IOException e)
		{
			System.out.println("Problem  with  file ");
			e.printStackTrace();
		}
		finally 
		{
			if (txtin!=null )txtin.close();
		}
		
		return  result; 
				 
		
	}

	private boolean register(String name, String password)
	{
		boolean success = false;
		PrintWriter usersOut = null;
		Scanner userFileScanner = null;
		try
		{

			File users = new File("data/server", "users.txt");

			boolean found = false;

			userFileScanner = new Scanner(users);
			while (userFileScanner.hasNext() && !found)
			{
				String user = userFileScanner.nextLine();
				if (user.contains(name))
				{
					found = true;
				}
			}
			if (!found)
			{
				String attempt = String.format("%s\t%s", name, password);
				usersOut = new PrintWriter(new FileWriter(users, true));
				usersOut.println(attempt);
				success = true;
			}
		}
		catch (IOException ex)
		{
			// TODO Auto-generated catch block
			ex.printStackTrace();
		}
		finally
		{
			if (usersOut != null) usersOut.close();
			if (userFileScanner != null) userFileScanner.close();
		}
		return success;
	}
	
	private void sendResponse(String response)
	{
		//	Send response to client
		txout.println(response);
		txout.flush();
	}

	/**
	* The code below is to fix problems with ImageIO.read not clearing all bytes of an image.
	*/
	private static void clearInput(InputStream is) throws IOException
	{
		int extra = is.available();
		if (extra > 0)
		{
			byte[] buffer = new byte[extra];
			is.read(buffer);
			System.out.println(extra + " " + new String(buffer));
		}
	}

}
