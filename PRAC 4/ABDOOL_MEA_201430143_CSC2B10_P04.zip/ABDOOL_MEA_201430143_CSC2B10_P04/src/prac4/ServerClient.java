package prac4;

import java.net.InetAddress;

public class ServerClient {
private  String name; //name of client
private  InetAddress address; //address of client 
private  int port; 
private   int ID;//gonna  give each  client and id  
public  int attempt=0;//if the cleint does not recieve a packet a specific amount of times that means they are not there
public ServerClient(String name ,InetAddress address , int port  )
{    
	ID=0;
	setPort(ID);
	this.setName(name);
	this.setAddress(address); 
	this.setPort(port); 

	
	
}
public int getID()
{
	return ID++; 
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getPort() {
	return port;
}
public void setPort(int port) {
	this.port = port;
	ID++;
}
public InetAddress getAddress() {
	return address;
}
public void setAddress(InetAddress address) {
	this.address = address;
}


}
