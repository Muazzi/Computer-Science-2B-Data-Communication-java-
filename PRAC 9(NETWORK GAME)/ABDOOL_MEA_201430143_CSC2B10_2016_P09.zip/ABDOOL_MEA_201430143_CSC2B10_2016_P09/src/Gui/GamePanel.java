package Gui;

import java.awt.GridLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;



import javax.swing.ImageIcon;
import javax.swing.JLabel;



public class GamePanel extends javax.swing.JPanel {
  /**
	 * 
	 */
	private static final long serialVersionUID = -7631423773664657198L;
private  JLabel  world [][]; 
  private  ImageIcon  player1,player2,banana,blank;
  private 	player p,p2,goal; 
  private ApplicationFrame frame;
  /**
   * 
   * @param frame will be actual  canvas  of the game  
   */
	public GamePanel(ApplicationFrame frame)
	{ 
		this.frame=frame;
		
		 
		this.requestFocus();
		setLayout(new GridLayout(10,10));
	
			setBanana(new ImageIcon(("data/images/banana.png")));
			blank = new ImageIcon( ("data/images/blank.png")); 
			 player1 = new ImageIcon(("data/images/monkey.png")); 
			 setPlayer2(new ImageIcon("data/images/harambe.png"));
		
	
		
		 addKeyListener(new userKey());
		world=new JLabel[10][10];
		for(int r=0;r<10;r++)
		{ 
			for(int c=0;c<10;c++)
			{
			world[r][c]=new JLabel();
			
			world[r][c].setIcon(blank);;//setting our world  to  be a blank  
			
			
			this.add(world[r][c]);
			
			}
		}    
		
		
		
		
				
	/**
	 *  getters for our world
	 */
	}
	public JLabel[][] getWorld() {
		return world;
	}
	/**
	 * 
	 * @param world which  will  be rendered
	 */
	public void setWorld(JLabel world[][]) {
		this.world = world;
	} 
	
	
	
	/**
	 * @return the goal
	 */
	public player getGoal() {
		return goal;
	}
	/**
	 * @param goal the goal to set
	 */
	public void setGoal(player goal) {
		this.goal = goal;
	}



	/**
	 * @return the p2
	 */
	public player getP2() {
		return p2;
	}
	/**
	 * @param p2 the p2 to set
	 */
	public void setP2(player p2) {
		this.p2 = p2;
	}

	public player getP() {
		return p;
	}
	/**
	 * @param p2 the p2 to set
	 */
	public void setP(player p) {
		this.p = p;
	}



	/**
	 * @return the player2
	 */
	public ImageIcon getPlayer2() {
		return player2;
	}
	/**
	 * @param player2 the player2 to set
	 */
	public void setPlayer2(ImageIcon player2) {
		this.player2 = player2;
	}

	public ImageIcon getPlayer1() {
		return player1;
	}
	/**
	 * @param player2 the player2 to set
	 */
	public void setPlayer1(ImageIcon player1) {
		this.player1 = player1;
	}



	/**
	 * @return the banana
	 */
	public ImageIcon getBanana() {
		return banana;
	}
	/**
	 * @param banana the banana to set
	 */
	public void setBanana(ImageIcon banana) {
		this.banana = banana;
	}
	public ImageIcon getBlank() {
		return blank;
	}
	/**
	 * @param banana the banana to set
	 */
	public void setBlank(ImageIcon blank) {
		this.blank = blank;
	}


	/**
	 * 
	 * @author Muaz class which will be used when  a key  event  occurs
	 *
	 */

	public class userKey extends KeyAdapter {
        public void keyPressed(KeyEvent e) {
            int keyCode = e.getKeyCode();
            
         
            	
            	  
            	// movement for up 	
            		
            if((keyCode==KeyEvent.VK_W) || (keyCode==KeyEvent.VK_UP)) 
     		 { 
  				
  				if(p.getRow()!=0)
  				{
  					 world[p.getRow()][p.getCol()].setIcon(blank);
  					 
  					 p.setRow(p.getRow()-1);
  					 frame.SendToServer("ME"+" "+p.getRow()+" "+p.getCol());
  					 
  					 world[p.getRow()][p.getCol()].setIcon(player1);
  					
  					
  				}
  				
  					
     			 
     			  
     			  
     			  
     			 
     			  // movement for down
     		 }
  			else if((keyCode==KeyEvent.VK_S) || (keyCode==KeyEvent.VK_DOWN))
{

  				if(p.getRow()!=9)
  				{
  					 world[p.getRow()][p.getCol()].setIcon(blank);
  					 
  					 p.setRow(p.getRow()+1);
  					 frame.SendToServer("ME"+" "+p.getRow()+" "+p.getCol());
  					 
  					 world[p.getRow()][p.getCol()].setIcon(player1);
  					
  					 
  				}
}                     
                //  movement for left 
  				else if((keyCode==KeyEvent.VK_A) || (keyCode==KeyEvent.VK_LEFT))
  				{

  				            				if(p.getCol()!=0)
  				            				{
  				            					 world[p.getRow()][p.getCol()].setIcon(blank);
  				            					 
  				            					 p.setCol(p.getCol()-1);
  				            					 frame.SendToServer("ME"+" "+p.getRow()+" "+p.getCol());
  				            					 
  				            					 world[p.getRow()][p.getCol()].setIcon(player1);
  				            			
  				            					 
  				            				}
  				
  				
  				
}  
  				// movement for right 
  				else if((keyCode==KeyEvent.VK_D) || (keyCode==KeyEvent.VK_RIGHT))
  				{

  				            				if(p.getCol()!=9)
  				            				{
  				            					 world[p.getRow()][p.getCol()].setIcon(blank);
  				            					 
  				            					 p.setCol(p.getCol()+1);
  				            					 frame.SendToServer("ME"+" "+p.getRow()+" "+p.getCol());
  				            					 
  				            					 world[p.getRow()][p.getCol()].setIcon(player1);
  				            				
  				            				}
  				}
            		
            		 
            	
            }
           {
               
          
         
        }
    }
	
  
   

}
