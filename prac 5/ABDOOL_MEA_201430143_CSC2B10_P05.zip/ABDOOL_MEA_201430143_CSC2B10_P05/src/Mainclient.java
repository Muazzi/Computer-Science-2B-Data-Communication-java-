import data.*;

public class Mainclient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 client cl = new  client();
	}

}
