package Gui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import java.net.Socket;

import javax.swing.JLabel;

public class player extends  JLabel  {
 /**
	 * 
	 */
	private static final long serialVersionUID = -7510431861317464478L;
private  int row;// row of the player
 private int  col;
 private  Socket PlayerSocket;
 private int score; 
 private PrintWriter outputtoplayer; 
 private BufferedReader  reader=null;
/**
 *  create  a player object  with a row col  in the world  and a socket for it 
 * @param r row of the player
 * @param col the column of theplayer
 * @param PlayerSocket each player will be assigned a connection 
 */ 
 public player (int r , int col,Socket PlayerSocket)
 {
	 setScore(0);//setting intial score to 0
	if(PlayerSocket!=null)
	{
		
		setPlayerSocket(PlayerSocket);
		try {
			outputtoplayer = new PrintWriter(getPlayerSocket().getOutputStream());//  seeting up streams
			reader =new BufferedReader(new InputStreamReader(PlayerSocket.getInputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	 this.setRow(r);
	this.setCol(col); 
	//this.setIcon(player);
 }
 /**
  * 
  * @return the row of the player
  */

public int getRow() {
	return row;
}

/**
 * 
 * @param row sets  the  row of the  player
 */
public void setRow(int row) {
	this.row = row;
}
/**
 * 
 * @return the col of the player
 */
public int getCol() {
	return col;
}
/**
 * 
 * @param col the column of the player
 */
public void setCol(int col) {
	this.col = col;
}



/**
 * 
 * @return the player socket or connection
 */
public Socket getPlayerSocket() {
	return PlayerSocket;
}
/**
 * 
 * @param playerSocket sets up the players socket or connection
 */
public void setPlayerSocket(Socket playerSocket) {
	PlayerSocket = playerSocket;
}
/**
 * 
 * @return the score of the playeer
 */
public int getScore() {
	return score;
}
/**
 * 
 * @param score sets the score of  the player
 */
public void setScore(int score) {
	this.score = score;
}
/**
 * 
 * @return
 */
public PrintWriter getOutputtoplayer() {
	return outputtoplayer;
}

public void setOutputtoplayer(PrintWriter outputtoplayer) {
	this.outputtoplayer = outputtoplayer;
}

/**
 * @return the reader 
 */
public BufferedReader getReader() {
	return reader;
}

/**
 * @param reader the reader to set
 */
public void setReader(BufferedReader reader) {
	this.reader = reader;
}
/**
 * 
 * @param msg the message from player to  server or  each other
 */ 
public void sendMessage(String msg)
{
	if (outputtoplayer!=null) {
		outputtoplayer.println(msg);
		outputtoplayer.flush();
	}
}
/**
 * 
 * @return the resposne from the player2 and server
 */
public String recieveMessage()
{
	String  response="";
	try {
		response = reader.readLine();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return response;
}
/**
 * close streams
 */
public void closeConnections()
{
	
	outputtoplayer.close();
	try {
		PlayerSocket.close();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
