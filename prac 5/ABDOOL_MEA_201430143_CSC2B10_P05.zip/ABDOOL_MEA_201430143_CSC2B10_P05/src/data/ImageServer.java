package data;

import java.io.Serializable;

public class ImageServer implements Serializable {
  private int id ; 
  private String name;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
} 
  
public  ImageServer(int id, String name)
{
	this.setId(id); 
	this.setName(name);
}
}
