package za.ac.uj.acsse.csc2b.pta.client;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.event.AncestorListener;

/**
 * @author STUDENT_NUMBER here
 */
public class POSTITClientFrame extends JFrame
{
	private  POSTITClient It = new  POSTITClient(); 
	private  boolean  status=false;
	private  JButton login   = new  JButton("Login"); 
	private  JButton Register   = new  JButton("Register"); 
	private  JButton loggoff   = new  JButton("logout"); 
	private  JButton post   = new  JButton("post"); 
	private  JTextArea  responses = new  JTextArea(20,20);
	public POSTITClientFrame()
	{
		//	Create client connection
		//	Create buttons for each command
		//	Use buttons to send commands using client connect 
		JPanel btnpanel = new JPanel(); 
		btnpanel.setLayout( new FlowLayout(FlowLayout.LEFT));
		
		btnpanel.add(Register);
		btnpanel.add(post);
		btnpanel.add(login);
		btnpanel.add(loggoff);
		JPanel details = new JPanel(); 
		details.setLayout(new  BorderLayout ());
		details.add(responses,BorderLayout.CENTER);
		this.add(details,BorderLayout.CENTER);
		
		this.add(btnpanel,BorderLayout.NORTH);
		
		
		Register .addActionListener(new  ActionListener ()
		{

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
			   String name  =  JOptionPane.showInputDialog("Please enter your name", null);
			   String pass  =  JOptionPane.showInputDialog("Please enter a password", null);
			   String message  = "REG"+" "+name+" "+pass;
			   It.sendMessage(message);
			    
			   String  response =  It.getResponse();
			   
			   responses.append(response);
			
			}
	
		}
		
		
		);
		
		
		
		
		
		login .addActionListener(new  ActionListener ()
				{

					@Override
					public void actionPerformed(ActionEvent arg0) {
						// TODO Auto-generated method stub
						 String name  =  JOptionPane.showInputDialog("Please enter your name", null);
						   String pass  =  JOptionPane.showInputDialog("Please enter a password", null);
						   String message  = "LOGIN"+" "+name+" "+pass;
						   It.sendMessage(message);
						   String  response =  It.getResponse();
						   responses.append(response);
						   if(response.contains("#ok"))
						   {
							   status=true; 
						   }
						   
						
					}
			
				}
				
				
				); 
		
		post.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				if(status==true)
				{
					String  title  =  JOptionPane.showInputDialog("Please enter A title for your  post ", null);
					 String clientMessage  =  JOptionPane.showInputDialog("Enter a message", null);
					   String message  = "POST"+" "+title+" "+clientMessage;
					   It.sendMessage(message);
					 JFileChooser choose  =  new JFileChooser(); 
					 int val = choose.showOpenDialog(POSTITClientFrame.this);
					 File  f =null;
					 if  ( val ==JFileChooser.APPROVE_OPTION)
					 {
						    f =choose.getSelectedFile();
					   
					      
						
						  
					 }
					 
						try
						{
							BufferedInputStream	bfs = new BufferedInputStream(new FileInputStream(f));
							
							 int filesize = 0;
							
								filesize = bfs.available();
						
								
								byte[] buffer = new byte[filesize];
								
									bfs.read(buffer);
								
								PrintWriter pw = It.getTxtout();
								pw.println(filesize + "");
								pw.flush();
								OutputStream output = It.getOS();
								
									output.write(buffer);
							
							
							
							
									output.flush();
							
									
							
								
									bfs.close();
						}
						catch (FileNotFoundException ex)
						{
							ex.printStackTrace();
						
						}
						catch (IOException e)
						{
							e.printStackTrace();
						}
						
					
						
							
					
						
					
					 
					String  r= It.getResponse(); 
					
					responses.append(r);
					 
					
				}
				else
				{
					responses.append(" you are not logged on " );
				}
				
				
				 
			}

		
			
			
		});
		
		loggoff.addActionListener(new  ActionListener ()
				
				{

					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						
						   It.sendMessage("LOGOFF");
						   status= false;
						   String response =  It.getResponse();
						   responses.append(response);
					}
			
				}
				
				
				
				);
		
		
		
		
		
	} 
	
	
}
