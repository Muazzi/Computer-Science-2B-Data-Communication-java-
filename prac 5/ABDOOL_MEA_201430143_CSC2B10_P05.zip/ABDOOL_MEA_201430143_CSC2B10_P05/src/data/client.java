package data;

import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;



public class client extends JFrame {
   
	class DisplayPanel extends JPanel
	{
		private BufferedImage image;

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.swing.JComponent#paintComponent(java.awt.Graphics)
		 */
		@Override
		protected void paintComponent(Graphics g)
		{
			// TODO Auto-generated method stub
			super.paintComponent(g);
			g.drawImage(image, 0, 0, getWidth(), getHeight(), null);
		}

		/**
		 * @return the image
		 */
		public BufferedImage getImage()
		{
			return image;
		}

		/**
		 * @param image
		 *            the image to set
		 */
		public void setImage(BufferedImage image)
		{
			this.image = image;
			this.repaint();
		}

	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	private BufferedImage img =null;
	private Socket			clientSocket;
	private InputStream		is;
	private PrintWriter		txtout;
	private BufferedReader	txtin;
	private JButton			btnimages;
	private JButton			btnupload;
	private JButton			retrieveimage;
	 private JTextArea  Displaylist;
	private DisplayPanel	imgPanel;
	private  ArrayList<ImageServer> list = new 	ArrayList<ImageServer>() ;
	 
	public client()
	{  
		setup();
		prepairGUI();
		
		
	}
	private void prepairGUI() {
		// TODO Auto-generated method stub
		retrieveimage = new JButton("RET");
		btnupload = new JButton("upload");
		btnimages = new JButton("List");
	  Displaylist = new  JTextArea();

		add(Displaylist,BorderLayout.EAST);
		btnimages.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				sendcommand("LIST"); 
				readobj();
				close();
				
			}
		});
		
		retrieveimage.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				String message = JOptionPane.showInputDialog(client.this,
                        "Please enter the image id ?", null);
				sendcommand("RET "+message);
				img = readImage();
				imgPanel.setImage(img);
				close();
				
			}
		});
		
		
		JPanel panlebtn = new  JPanel(); 
		panlebtn.add(btnupload);
		panlebtn.add(btnimages);
		panlebtn.add(retrieveimage);
		add(panlebtn, BorderLayout.WEST );
		
		
		
	

		imgPanel = new DisplayPanel();
      add (imgPanel, BorderLayout.CENTER);
	
	

		
		

		

		setSize(800, 600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);

		
	}
	
	private BufferedImage readImage()
	{
		BufferedImage image = null;
		try
		{
			image = ImageIO.read(is);
			// The code below is to fix problems with ImageIO.read
			// not clearing all bytes of an image.
			int extra = is.available();
			if (extra > 0)
			{
				byte[] buffer = new byte[extra];
				is.read(buffer);
				System.out.println(extra+" "+new String(buffer));
			}
		}
		catch (IOException ex)
		{
			ex.printStackTrace();
		}
		return image;
	}
	private  void  setup()
	{
		try {
			clientSocket =  new Socket("localhost",7451);
			txtout =  new  PrintWriter(clientSocket.getOutputStream()); 
			is=clientSocket.getInputStream(); 
			txtin = new BufferedReader(new InputStreamReader(is));
			//sendcommand("RET 1");
			//readobj();
			//readResponse();
			
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}  
	private void close()
	{
		if (clientSocket != null)
		{
			try
			{
				clientSocket.close();
				clientSocket = null;
			}
			catch (IOException ex)
			{
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}

	} 
	public void Clearspace(InputStream in)
	{
		int rem; 
		try{
			rem= in.available();
			if(rem>0)
				{
					byte[] trash=new byte[rem];
					in.read(trash);
				}
		} 
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	
	
	private void sendcommand(String string) {
		// TODO Auto-generated method stub
	 txtout.println(string);
	 txtout.flush();
	}
	
	private void readResponse()
	{
		try
		{
			String response = txtin.readLine();
			System.out.println(response);
		}
		catch (IOException ex)
		{
			ex.printStackTrace();
		}
	}  
	
	private  void  readobj()
	{
		 
		  try {
			ObjectInputStream objectInput = new ObjectInputStream(clientSocket.getInputStream());
			try {
				Object object = objectInput.readObject();
				list =(ArrayList<ImageServer> )object;
				for(ImageServer d: list)
				{ 
					Displaylist.append("ID:" +Integer.toString(d.getId())+" "+  "name:"+ d.getName()+"\n\r");
					
				}
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	


	

}
