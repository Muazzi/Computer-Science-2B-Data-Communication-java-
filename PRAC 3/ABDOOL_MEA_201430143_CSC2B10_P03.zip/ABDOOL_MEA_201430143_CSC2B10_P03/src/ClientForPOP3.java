import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Inet4Address;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class ClientForPOP3 {
private String username; 
private String Password;


public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return Password;
}
public void setPassword(String password) {
	Password = password;
} 
public ClientForPOP3(String Username,  String password  )
{
	this.username=Username; 
	this.Password= password;
	
	
}


public void   CheckForError(String Response)
{
	if (Response.charAt(0)!= '+')
	{
		System.err.println("Error in response");
		
	}
}






public  void readmail() throws UnknownHostException, IOException
{         
    	Socket s = new Socket("127.0.0.1", 110); 
    	InputStream i = s.getInputStream();
    	OutputStream o = s.getOutputStream(); 
    	BufferedReader r = new BufferedReader(new InputStreamReader(i));
    	PrintWriter w = new PrintWriter(o); 
    	
    	 System.out.println ("S:" + r.readLine ());
    	 w.println("USER "+username);
    	 
    	 w.flush();
    	
    	 w.println("PASS "+Password);

    	 w.flush();
    	 w.println("LIST");
    	
    	 w.flush();
        
    	 String output  =" - ";
    	 while(output!=null &&!output.equalsIgnoreCase("."))
    	 {
    		 System.out.println("s:"+output);
    		 output= r.readLine();
    	 }
    	
    	 w.println("RETR ");
    	 w.flush();
    	 
   
    	 
       

}
}
