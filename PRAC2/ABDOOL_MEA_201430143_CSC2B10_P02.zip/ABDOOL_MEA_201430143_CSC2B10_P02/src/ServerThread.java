import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Random;
import java.util.StringTokenizer;
/**
this class will  spawn thread to make it a multithreaded server 
**/
public class ServerThread extends Thread {
private Socket sock; 
public ServerThread( Socket sock)
{
	this.sock= sock ; 
	
}
 public void run()
 {     
	 try {
		BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
		PrintWriter pw =  new PrintWriter(sock.getOutputStream(),true); 
		String x = "01 WELCOME - You may ask  5 questions  ";
		pw.println(x);
		String Message  = in.readLine(); 
		System.out.println(Message);
		
		int numreplies=0;
			
         boolean keep_asking=true;
			
			while(keep_asking)
  
			{  
				pw.println("02 ASK your Question or  DONE  ");
				Message = in.readLine();
				
			   if(Message.equals("DONE"))
			   { 
				   pw.println("04 Goodbye - X Questions answered");
				   keep_asking= false; 
			   }   
			  
			         StringTokenizer reply  = new  StringTokenizer(Message); 
			         
			        String Evaluate =  reply .nextToken();
			       
			           
			        if (Evaluate.equals("ASK"))
			        {
			        	  Evaluate =  reply.nextToken();
						  switch(Evaluate)
						  {
						  case "WHY":
						  case "Why":
						  case "why":
							  pw.println("03 Because it is just like that");
							  numreplies++;
						  break; 
						  case"ARE":
						  case"Are":
						  case"are":
							  pw.println("03 "+GenerateAreresult());
							  numreplies++;
						  break ; 
						  default:
							pw.println("03 "+GenerateOtherresult());
							numreplies++;
							break ;  
						  
						  }
						
						  System.out.println(numreplies);
						  if(numreplies==5)
						  {
							  pw.println("05 Goodbye - 5 Questions answered");
							  keep_asking=false  ;
						  }
						 
			        	
			        }
			       
					 
					 
			   }
			
			pw.println("GOODBYE");
			
		
		
			   
			 
			   
			 
		
			
	

			
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}  
	 finally
	 {
		 try
			{
				System.out.println("Clearing up");
				sock.close();
			}
			catch (IOException ex)
			{
				System.err.println("connection  errror ");
				
			}
	 }
	 
 }
 
 
 public  String  GenerateAreresult ()
 {
	 String [] ary = {"Yes","No ","Maybe" };
	 int index = new Random().nextInt(ary.length);
	 return  ary[index]; 
	 
 }
 public  String  GenerateOtherresult ()
 {
	 String [] ary = {"42","Please ask again","Meh"};
	 int index = new Random().nextInt(ary.length);
	 return  ary[index]; 
	 
 }
 
 
}
