


import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import data.ServerHandler;
public class server {
  private ServerSocket  Myserver ; 
   private  boolean  running; 
   final static  int PORT =  7451;
   public  server(int port)
   
   {
	   try
	   {
		   System.out.println("awaiting connection  on port "+ PORT);
		   Myserver =  new ServerSocket(port);
		   running =  true; 
		   start();
	   }
	   catch (IOException e)
	   {
		   e.printStackTrace();
	   }
	   
   }
   
   
	private void start() {
	// TODO Auto-generated method stub
		System.out.println("Our server has started ");
		while(running)
		{
			try {
				Socket socket =  Myserver.accept() ;
				System.out.println("New Client"); 
				  ServerHandler handel = new ServerHandler(socket) ;
				  Thread   t = new  Thread(handel);
				  t.start();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	
}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
    server se = new  server(PORT);
	}
  
}
