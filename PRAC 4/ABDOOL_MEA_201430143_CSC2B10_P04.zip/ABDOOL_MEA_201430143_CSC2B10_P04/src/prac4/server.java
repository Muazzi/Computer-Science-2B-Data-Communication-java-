package prac4;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JTextArea;

public class server implements Runnable   {
public List<ServerClient>cleints =  new ArrayList<ServerClient>(); 	
private int port ; 
private DatagramSocket socket; 
private Thread run,manage, send ,recieve ; 
private boolean running = false; 
private ServerClient cl = null; 
JTextArea area =new JTextArea(); 
	public server(int port)
	{  
		ServerGUI gui= new ServerGUI(); 
		area= gui.getArea();
		this.port=port;
		try {
			socket = new DatagramSocket(port);
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		run =  new Thread(this,"serverthread");
		run.start();
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		running=true; 	
		System.out.println("server started on  port"+port);
		area.append("server started on  port"+port+"\n");
		manageclients(); 
		recieve();
		while(running)
		{
			
		}
		
	}
	
	private void recieve() {
		recieve= new Thread("recieve")
				{
			    public  void run ()
			    {
			    	while(running)
			    	{
			    		//recieve
			    		byte [] data = new byte[1024];
			    		DatagramPacket p = new DatagramPacket(data, data.length);
			    		try {
							socket.receive(p);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
			    		process(p);
			    		
			    		
			    		
			    		//NOW WE CAN ACESS EACH  CLIENT AND PULL THEIR  DETAILS  
			    		
			    	
			    	}
			    }
				} ;
				recieve.start();
		
	}
	private void process (DatagramPacket p )
	{   
		String s = new String (p.getData(),p.getOffset(),p.getLength()); 
		//System.out.println(s);
		if(s.startsWith("\\HOWZIT"))
		{
			String username =  s.substring(8, s.length()); 
			InetAddress address=  p.getAddress(); 
			int port =  p.getPort();
			System.out.println("AWE "+username+ cleints.size()+"\n");
			area.append("S:"+"AWE "+username+"," + cleints.size()+"\n");
			cl= new ServerClient(username,address,port) ;
			
			
			cleints.add(new ServerClient(cl.getName(),cl.getAddress(),cl.getPort()));
			
			
		}
		else if (s.startsWith("\\CHINA"))
		{
			System.out.println("AWE"+cl.getName()+"," +cl.getID());
			area.append("S:"+"AWE "+cl.getName()+cleints.size()+"\n");
			for(ServerClient CL : cleints)
			{
				System.out.println(CL.getName()+CL.getAddress()+CL.getPort());
				
				area.append(CL.getName() +CL.getAddress() +CL.getPort() +"\n");
			}
		}
		else if (s.startsWith("\\TUNE"))
		{
	    String message= s.substring(5, s.length());
	    sendToAll(message);
		}
		else if (s.startsWith("\\SHARP"))
		{
		 int id = cl.getPort(); 
		 disconnet(id);
		 
		 area.append(cl.getName() +" has logged off" +"\n");
		 sendToAll(cl.getName() +" has logged off");
		}
		else
		{
			// send  EISH ERRROR HAS OCCURED
			System.out.println("EISH  SOMETHING WENT WRONG BABA!");
			area.append("EISH  SOMETHING WENT WRONG BABA!");
		}
	}
	private void sendToAll(String message) {
		for ( int i = 0 ; i<cleints.size();i++)
		{
			ServerClient cl  = cleints.get(i); 
			send(message.getBytes(),cl.getAddress(), cl.getPort());
			area.append(message +"\n");
		}
		
	}
	private void disconnet (int port)
	{
		for(int i = 0; i<cleints.size();i++)
		{
			if(cleints.get(i).getPort()==port)
			{
				cleints.remove(i);
				break; 
			}
				
			
		}
	}
	private void send(final byte[] data,InetAddress address, final int port)
	{
	
		send =  new  Thread ("Send")
		{
	     public void run ()
	     {
	    	 DatagramPacket  packet= new DatagramPacket(data,data.length,address, port);  
	    	 try {
				socket.send(packet);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	     }
		};
		send.start();
	}
	private void manageclients()
	{
		// keep track of clients 
		manage=  new Thread("manage"){
			public void run()
			{
				while(running)
				{
					// gonna do some managing 
				}
			}
		};
		manage.start();
		
	}
	public ServerClient getCl() {
		return cl;
	}
	public void setCl(ServerClient cl) {
		this.cl = cl;
	}
	
}
