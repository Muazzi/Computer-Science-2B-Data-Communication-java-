package Gui;


import java.io.InputStream;
import java.io.OutputStream;
import java.util.Random;
import java.util.StringTokenizer;

public class Protocolhandler implements Runnable  {
private player p1,p2,g; 
private InputStream player1input;
private OutputStream player1output, player2output;

/***
 *  it will  send  assign  the way  we send messages to  one  another
 * @param p1 player oner object
 * @param p2 player two object 
 * @param g the goal object 
 */
public Protocolhandler(player p1,player p2,player g)
{
	this.p1=p1; 
	this.p2=p2; 
	this.g=g;
	
	
}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
			
			
			p1.sendMessage("MONKEY"+" "+p1.getRow()+" "+p1.getCol());//  player one is the monkey  send  cordinates  
			p1.sendMessage("BABOON"+" "+p2.getRow()+" "+p2.getCol());//  player 2 is harambe  it swill be sent its cordinates
			p1.sendMessage("BANANA"+" "+g.getRow()+" "+g.getCol());//  each  player will have  the cordinates  of the banana which is the goal  in this case 
			
			
			
			boolean  control=true;
			
			while(control)
			{
				String response= p1.recieveMessage();
				StringTokenizer a = new StringTokenizer(response, " ");
				String skip = a.nextToken(); // we skipping the message we dont need it  
				
				p1.setRow(Integer.parseInt(a.nextToken()));
				p1.setCol(Integer.parseInt(a.nextToken()));
				// if we  touch the goal
				if(p1.getRow()==g.getRow()&&p1.getCol()==g.getCol())
				{
					p1.setScore(p1.getScore()+1);
					if(p1.getScore()>=3)  // logic of game
					{
						p1.sendMessage("WIN");
						p2.sendMessage("LOSE");
					p1.closeConnections();
						p2.closeConnections();
						control=false;
					}
					else
					{
						//place the goal somewhere else
						int r = RandomNumber(0,9);
						int c=RandomNumber(0,9);
						g.setRow(r);
						g.setCol(c);
						p2.sendMessage("BABOON"+" "+p1.getRow()+" "+p1.getCol());
						p2.sendMessage("BANANA"+" "+g.getRow()+" "+g.getCol());
						p1.sendMessage("BANANA"+" "+g.getRow()+" "+g.getCol());
								
					}
					
				}
				else
				{  //send message to the other laer
					p2.sendMessage("BABOON"+" "+p1.getRow()+" "+p1.getCol());
				}
				
					
				
				
				
			
				
			}
			
			
		
		
	}
	
	/**
	 * 
	 * @param min the min  number
	 * @param max the max number
	 * @return a random number
	 */
	 private int RandomNumber(int min ,  int max)
	 {
		
		 Random rand = new Random();
		 long range= (long)max-(long)min +1; 
		 long fraction = (long)(range*rand.nextDouble());
		 int randomnum=(int)(fraction+min);
		 return  randomnum;
	 }
	 /**
	  * 
	  * @return inputstream
	  */
	public InputStream getPlayer1input() {
		return player1input;
	}
	/**
	 * 
	 * @param player1input inputsream
	 */
	public void setPlayer1input(InputStream player1input) {
		this.player1input = player1input;
	}
	/**
	 * 
	 * @return output stream
	 */
	public OutputStream getPlayer1output() {
		return player1output;
	}
	/**
	 * 
	 * @param player1output outputstream
	 */
	public void setPlayer1output(OutputStream player1output) {
		this.player1output = player1output;
	}
	/**
	 * 
	 * @return player 2 outputstream
	 */
	public OutputStream getPlayer2output() {
		return player2output;
	}
	/**
	 * 
	 * @param player2output ouputstreams
	 */
	public void setPlayer2output(OutputStream player2output) {
		this.player2output = player2output;
	}
	}
