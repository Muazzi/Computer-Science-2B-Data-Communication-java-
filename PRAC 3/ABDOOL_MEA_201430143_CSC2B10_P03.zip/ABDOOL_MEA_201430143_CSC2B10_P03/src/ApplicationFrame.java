import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.UnknownHostException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ApplicationFrame extends JFrame{
	private JLabel lblusername= new  JLabel("Username");
	private JLabel lblpassword= new  JLabel("password");
	private JTextField txtuser = new JTextField(50);
	private JTextField txtpass = new JTextField(50);
	private JButton  btnLogin  = new  JButton("Login "); 
    private String Username ; 
    private String Password; 
    private ClientForPOP3 client;
    
	public  ApplicationFrame()
	{
		JPanel  User  = new  JPanel(); 
		User.add(lblusername); 
		User.add(txtuser); 
		JPanel pass = new JPanel(); 
		pass.add(lblpassword);
		pass.add(txtpass);
		
		JPanel  LoginWindow = new JPanel ();
		LoginWindow.setLayout(new  BorderLayout());
		LoginWindow.add(User ,BorderLayout.NORTH);
		LoginWindow.add(pass ,BorderLayout.CENTER); 
		btnLogin.addActionListener(new ActionListener() 
				{

					@Override
					public void actionPerformed(ActionEvent arg0) {
						Username=txtuser.getText(); 
						Password= txtpass.getText(); 
						client = new ClientForPOP3(Username,Password  ) ;
						try {
							client.readmail();
						} catch (UnknownHostException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						// TODO Auto-generated method stub
						
						
					}
			
			
				}
				
				
				);
		
		this.add(LoginWindow,BorderLayout.NORTH);
	
		this.add(btnLogin,BorderLayout.SOUTH);
		this.pack();
		this.setLayout(new BorderLayout());
		this.setSize(1280,480);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);

	}

}
